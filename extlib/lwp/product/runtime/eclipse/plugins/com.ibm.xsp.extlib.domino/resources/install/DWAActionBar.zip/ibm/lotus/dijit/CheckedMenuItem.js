// Extends dijit.CheckedMenuItem to allow a menu item image together with the checkmark
dojo.provide("ibm.lotus.dijit.CheckedMenuItem");
dojo.require("dijit.CheckedMenuItem");
dojo.declare("ibm.lotus.dijit.CheckedMenuItem", dijit.CheckedMenuItem, {
	templateString: dojo.cache("ibm.lotus.dijit", "templates/CheckedMenuItem.html") 
});

