dojo.provide("ibm.lotus.dijit.ActionBar");
dojo.require("dijit.MenuItem");
dojo.require("dijit.MenuBar");

dojo.declare("ibm.lotus.dijit._ActionBarItemMixin", null, {
	
	templateString: dojo.cache("ibm.lotus.dijit", "templates/ActionBarItem.html"),
	
	// Workaround for focus management bug in dijit.MenuBar
	_onFocus: function(item) {
		this.getParent().focusedChild = this;
		this.inherited(arguments);
	}
});

dojo.declare("ibm.lotus.dijit.ActionBarItem", [dijit.MenuItem, ibm.lotus.dijit._ActionBarItemMixin], {
	postCreate: function() {
		dojo.addClass(this.focusNode, "actionBarDefaultAction");
	},
	
	// summary:
	//		Item in a MenuBar that's clickable, and doesn't spawn a submenu when pressed (or hovered)
	_onClickConditional: function(evt) {
		this._onClick(evt);
	}
	
});

dojo.declare("ibm.lotus.dijit.PopupActionBarItem", [dijit.PopupMenuItem, ibm.lotus.dijit._ActionBarItemMixin], {
	// summary:
	//		Item in a MenuBar like "File" or "Edit", that spawns a submenu when pressed (or hovered)
	
	// If true, then clicking on the menu item label (as opposed to the down arrow)
	// is the same as expanding the menu and selecting the first item.
	hasOnClick: false,
	
	startup: function(){
		if(this._started){ return; }
		this.inherited(arguments);
		if(this.arrowWrapper){
			dojo.style(this.arrowNode, "display", "");
		}
	},
	
	_setOnClickAttr: function(action) {
		this.hasOnClick = ibm.lotus.dijit.PopupActionBarItem.superclass.onClick !== action;
		dojo.toggleClass(this.focusNode, "actionBarDefaultAction", this.hasOnClick);
	},
	
	_onClickConditional: function(evt) {
		if (this.hasOnClick) {
			var popup = this.popup;
			this.popup = null;
			if (popup && popup.isShowingNow) {
				popup.onCancel();
			}
			this.getParent().onItemClick(this, evt);
			this.popup = popup;
		} else {
			this._onClick(evt);
		}
	}

});

dojo.declare("ibm.lotus.dijit.ActionBar", [dijit.MenuBar], {
	constructor: function(){
		// Override orientation specified by MenuBar constructor to account for 
		// right-aligned popup menubar items.
		this._orient = this.isLeftToRight() ? {BL: 'TL', BR:'TR'} : {BR: 'TR', BL:'TL'};
	}
});